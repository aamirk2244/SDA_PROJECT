package Registration.Remove_Student;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;

import java.sql.*;

public class RemoveStudentUi_Controller {
    @FXML
    Pane panel;
    @FXML
    public TextField text_field;
    @FXML public TableView<remove_student_info> table;
    @FXML public TableColumn<remove_student_info, String> student_id;
    @FXML public TableColumn<remove_student_info, String> student_name;
    @FXML public TableColumn<remove_student_info, String> student_class;
    @FXML private Label label;
    private int ID;
    private String NAME;
    private String CLASS;
    private int Total_students_or_teachers;
    private Connection con;
    private String query;
    private PreparedStatement stmt;
    private ResultSet rs;


    public void controller()
    {
        System.out.println("This is the contrller class ");
    }

    public ObservableList<remove_student_info> getStudent()
    {
        System.out.println("Returnig Teacher from here");
        con = null;
        query = "select * from student_list";
        rs = null;
        ObservableList<remove_student_info> student = FXCollections.observableArrayList();

        try {

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Students","root","");

            stmt = con.prepareStatement(query);

            rs = stmt.executeQuery();

            while(rs.next())
            {
                System.out.println("HEHEHEEHHE");

                ID = rs.getInt("student_id");
                NAME = rs.getString("student_name");
                System.out.println("NAME IS " + NAME);
                CLASS = rs.getString("student_class");
                System.out.println(ID);

                student.add(new remove_student_info(NAME, ID, CLASS));

                Total_students_or_teachers += 1;
            }
            label.setText("Total Students are " + Total_students_or_teachers);

        }catch (Exception e){//do nothing
            System.out.println("Error in connection " + e);
        }
        System.out.println("Observable list is called correctly");
//        teacher.add(new remove_teacher_info(23, "Safiullah", "medical"));
        System.out.println(student);
        return student;
    }
    @FXML
    private void initialize() {
        // this method will call automatically when all fxml files are loaded
        execute_table();
    }
    public void execute_table()
    {


        student_id.setCellValueFactory(new PropertyValueFactory<>("student_id"));
        student_name.setCellValueFactory(new PropertyValueFactory<>("student_name"));
        student_class.setCellValueFactory(new PropertyValueFactory<>("student_class"));
        ObservableList<remove_student_info> get_list  = getStudent();
        System.out.println("returned back");
        System.out.println(get_list.get(0).getStudent_name());
        table.setItems(get_list);

    }
    public void button_clicked()
    {
        System.out.println("this is selected");
        int idd =    table.getSelectionModel().getSelectedItem().getStudent_id();
        table.getItems().removeAll(table.getSelectionModel().getSelectedItem());
//                System.out.println(table.getItems().get(0).getName());
        System.out.println("The remove button has been clicked");
        String id = Integer.toString(idd);
        query = "DELETE FROM student_list WHERE student_id = "  + id;

        // the below code will remove the row from the Database Based on the query
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Students","root","");
             Statement stmt = conn.createStatement();) {

            stmt.executeUpdate(query);
            System.out.println("Record deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
