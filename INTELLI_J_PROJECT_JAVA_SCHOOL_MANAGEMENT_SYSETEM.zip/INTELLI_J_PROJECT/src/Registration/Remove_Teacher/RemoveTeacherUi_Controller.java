package Registration.Remove_Teacher;
// this table code is same everywhere so ratta lagao ismay.
//  From this Class I used JAVAFX library
// this is the controller class for remove teacher
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;

import java.sql.*;

import javax.crypto.spec.PSource;
import java.util.Arrays;


public class RemoveTeacherUi_Controller {
    @FXML
    Pane panel;
    @FXML
    public TextField text_field;
    @FXML public TableView<remove_teacher_info> table;
    @FXML public TableColumn<remove_teacher_info, String> teacher_id;
    @FXML public TableColumn<remove_teacher_info, String> teacher_name;
    @FXML public TableColumn<remove_teacher_info, String> teacher_subject;
    @FXML private Label label;
    private int ID;
    private String NAME;
    private String CLASS_OR_subject;
    private int Total_students_or_teachers;
    private Connection con;
    private String query;
    private PreparedStatement stmt;
    private ResultSet rs;
    public RemoveTeacherUi_Controller()
    {
        Total_students_or_teachers = 0;
        System.out.println("constructor is called of Remove_teacherUi");
    }

    public void controller()
    {
        System.out.println("This is the contrller class ");
    }

    public ObservableList<remove_teacher_info> getTeacher()
    {
        System.out.println("Returnig Teacher from here");
        con = null;
        query = "select * from teacher_list";
        rs = null;
        ObservableList<remove_teacher_info> teacher = FXCollections.observableArrayList();

        try {

            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Teachers","root","");

            stmt = con.prepareStatement(query);

            rs = stmt.executeQuery();

            while(rs.next())
            {

                ID = rs.getInt("id");
                NAME = rs.getString("Name");
                System.out.println("NAME IS " + NAME);
                CLASS_OR_subject = rs.getString("Subject");
                System.out.println(ID);

                teacher.add(new remove_teacher_info(ID, NAME, CLASS_OR_subject));

                Total_students_or_teachers += 1;
            }
            label.setText("Total Teacher are " + Total_students_or_teachers);

        }catch (Exception e){//do nothing
            System.out.println("Error in connection " + e);
        }
        System.out.println("Observable list is called correctly");
//        teacher.add(new remove_teacher_info(23, "Safiullah", "medical"));
        System.out.println(teacher);
        return teacher;
    }
    @FXML
    private void initialize() {
        // this method will call automatically when all fxml files are loaded
        execute_table();
    }
    public void execute_table()
    {


        teacher_id.setCellValueFactory(new PropertyValueFactory<>("id"));
        teacher_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        teacher_subject.setCellValueFactory(new PropertyValueFactory<>("subject"));
        ObservableList<remove_teacher_info> get_list  = getTeacher();
        System.out.println("returned back");
        System.out.println(get_list.get(0).getName());
        table.setItems(get_list);

    }
    public void button_clicked()
    {
        System.out.println("this is selected");
        int idd =    table.getSelectionModel().getSelectedItem().getId();
        table.getItems().removeAll(table.getSelectionModel().getSelectedItem());
//                System.out.println(table.getItems().get(0).getName());
        System.out.println("The remove button has been clicked");
        String id = Integer.toString(idd);
        query = "DELETE FROM teacher_list WHERE id = "  + id;

        // the below code will remove the row from the Database Based on the query
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Teachers","root","");
             Statement stmt = conn.createStatement();) {

            stmt.executeUpdate(query);
            System.out.println("Record deleted successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}