package Registration.Remove_Teacher;

import com.aamir.Database_Connection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javax.swing.*;

public class Remove_Teacher extends Application {

    public static void base_main(JFrame tmp_frame)
    {
        tmp_frame.dispose();
        System.out.println("I am called brother");
        if(!Database_Connection.is_connection_made("jdbc:mysql://localhost:3306/Teachers"))
        {
            return;
        }
        try{
            launch();   // this will call to the start function by default
            // if launch is called 2 times in one programm then exception will be raised

        } catch(Exception e){
            JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(null), "Restart your Program!",
                    "One Time Execution is Allowed", JOptionPane.ERROR_MESSAGE);
        }


    }

    @Override
    public void start(Stage primaryStage)throws Exception {
        System.out.println("StuCK HERE");
        Parent root = FXMLLoader.load(getClass().getResource("remove_teacher_ui.fxml"));
        System.out.println("YAHHA HOOO");

        primaryStage.setTitle("Remove Teacher");

        primaryStage.setScene(new Scene(root));

        System.out.println(root.getStyle());

        primaryStage.show();
    }
}
