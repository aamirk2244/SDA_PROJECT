package show_student_teacher;
// this file also contain the attendence of the students
import javax.swing.*;
import javax.swing.event.CellEditorListener;
import javax.swing.plaf.IconUIResource;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class student_and_teacher implements ItemListener, ActionListener {
    private JLabel head_text;
    private JTable table1;
    private JComboBox comboBox1;
    private JLabel class_label;
    private JPanel panel;
    private JLabel TotalStudent_label;
    private JLabel msg;
    private JLabel msg2;
    private JFrame frame;
    public boolean take_attendence;
    public JButton submit;
    private JButton ABSENT;
    public String[] s = new String[13];
    private int current_class_is;
    private int[] absent_mark = new int[30];
    private int absent_mark_index;
    public void set_student_classes()
    {

       for(int i = 0; i < 13; i++)
       {
           if(i == 0)
           {
               s[i] = "All Students";
           }
           else
           {

               s[i] = Integer.toString(i);
           }
       };
    }
    public void create_table(String id , String Name, String class_or_subject, String Attendence)
    {
        System.out.println("this is attendence " + this.take_attendence);
        if(take_attendence)
        {
            System.out.println("yes reached here");
            String[] column = {id ,Name, class_or_subject, Attendence};
            Object[][] data = null;
            table1.setModel(new DefaultTableModel(data, column));
            table1.setShowGrid(true);
            return;
        }
        String[] column = {id ,Name, class_or_subject};
        Object[][] data = null;
        table1.setModel(new DefaultTableModel(data, column));
       table1.setShowGrid(true);
    }
    // using method overloading for default parameter
    public void create_table(String id , String Name, String class_or_subject)
    {
        create_table(id, Name, class_or_subject, "");
    }
    public void set_frame(String heading, boolean show_student)
    {
        frame = new JFrame();
        panel.setLayout(new FlowLayout());
        head_text.setText(heading);
        frame.setVisible(true);
     //   frame.setLocationRelativeTo(null);
        frame.setSize(800, 700);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        frame.setContentPane(panel);
        if(show_student)
        {
            class_label.setText("Class");
            for(int i = 0 ; i < 13; i++)
            {
                comboBox1.addItem(s[i]);
                if(i != 0)
                {
                    comboBox1.getItemAt(i); // for choosing class

                }

            }
         comboBox1.addItemListener(this);

        }
        else
        {
            class_label.setText("");
        }

    }


    public void main_of_student_and_teacher ( boolean show_student, boolean show_teacher, JFrame temp_frame, boolean take_attendence)
    {
        msg.setVisible(false);
        msg2.setVisible(false);

        absent_mark_index = 0;
        for(int i = 0; i < 30; i++)
        {
            absent_mark[i] = -1;
        }

        this.take_attendence = take_attendence;
        temp_frame.dispose();
        set_student_classes();
        if(show_student)
        {
            set_frame("Students List", true);
            if(take_attendence)
            {
                submit = new JButton("Submit");
                ABSENT = new JButton("Absent");
                ABSENT.setBounds(60,100,95,30);

                submit.setBounds(50,100,95,30);
                frame.add(ABSENT);

                frame.add(submit);
               submit.setBackground(Color.red);
               ABSENT.setBackground(Color.green);

                submit.setVisible(false);
                msg.setVisible(false);
                msg2.setVisible(false);
                submit.addActionListener(this);
                ABSENT.setVisible(false);

                ABSENT.addActionListener(this);

            }
            show_student_of_class(0, show_student);
        }
        else if(show_teacher)
        {
            // 22 is dummy value in this case
            show_student_of_class(22, false);
            set_frame("Teachers List", false);
        }


    }
    // method overloading for default argument
    public void main_of_student_and_teacher( boolean show_student, boolean show_teacher, JFrame temp_frame)
    {
        main_of_student_and_teacher(show_student, show_teacher, temp_frame, false);

    }
    private void show_student_of_class(int number, boolean is_show_student)
    {
       //  select * from student_list where student_class = "12";



        String position = Integer.toString(number);
        String query;
        if(is_show_student)
        {
            System.out.println("current class is " + current_class_is);
            if(number == 0)
            {
                query = "select * from student_list";
            }
            else
            {
                query = "select * from student_list where student_class = " +  position;
            }
        }
        else
        {
            query = "select * from teacher_list";
        }

        Connection con;
        try{

            Class.forName("com.mysql.cj.jdbc.Driver");
            if(is_show_student)
            {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Students","root","");

            }
            else {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Teachers","root","");
            }
            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();
            int ID;
            String NAME;
            String CLASS_OR_subject;
            if(is_show_student && take_attendence)
            {
                create_table("Student Id", "Name ","Class", "Attendence");

            }
            else if(is_show_student)
            {
                create_table("Student Id", "Name ","Class");

            }
            else{
                create_table("Teacher Id", "Name ","Subject");

            }
            DefaultTableModel model = (DefaultTableModel) table1.getModel();
            int Total_students_or_teachers = 0;
            if(is_show_student)
            {

                while(rs.next())
                {

                    ID = rs.getInt("student_id");
                    NAME = rs.getString("student_name");
                    CLASS_OR_subject = rs.getString("student_class");
                    model.addRow(new Object[]{ID, NAME, CLASS_OR_subject, "-"});
                    Total_students_or_teachers += 1;
                }
                TotalStudent_label.setText("Total Students are " + Total_students_or_teachers);

            }
            else
            {
                while(rs.next())
                {

                    ID = rs.getInt("id");
                    NAME = rs.getString("Name");
                    CLASS_OR_subject = rs.getString("Subject");

                    model.addRow(new Object[]{ID, NAME, CLASS_OR_subject});
                    Total_students_or_teachers += 1;
                }
                comboBox1.setVisible(false);

                TotalStudent_label.setText("Total Teachers are " + Total_students_or_teachers);

            }

            table1.setRowHeight(22);
            TableColumnModel columnModel = table1.getColumnModel();
            columnModel.getColumn(1).setPreferredWidth(120);
            columnModel.getColumn(0).setPreferredWidth(10);
            columnModel.getColumn(2).setPreferredWidth(3);
            System.out.println("REACHED HERE ");

        }
        catch(Exception e)
        {
            System.out.println("Error in connection"+e);
            JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(null), "Server is not running!",
                    "Network Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        System.out.println("ITEM LISTENER PRESSED");

        for(int i = 0 ; i < 13; i++)
        {
            if(e.getItem() == s[i])
            {
                current_class_is = i;
                if(take_attendence && i!=0)
                {
                    submit.setVisible(true);
                    msg.setVisible(true);
                    msg2.setVisible(true);
                    submit.setActionCommand("S");

                    ABSENT.setVisible(true);
                    ABSENT.setActionCommand("A");
                }

                show_student_of_class(i, true);
            }
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand() == "S")     // if submit button is clicked
        {

            System.out.println("yes submit button is pressed");
            Object[] rowData = new Object[table1.getColumnCount()];
            int column = table1.getColumnCount();

            int rows = table1.getRowCount();
            int row_index = 0;
            int total_files_of_attendence = 0;

            String saving_path = "src/Student_Attendence_Info/" + current_class_is+ "/";

            try {
                String file_path = "src/Student_Attendence_Info/" + current_class_is;
                File directory = new File(file_path);
                total_files_of_attendence = directory.list().length;
                total_files_of_attendence += 1;
                saving_path = saving_path + total_files_of_attendence + ".txt";
                FileWriter fout = new FileWriter(saving_path);
                fout.write("ID\tName\tClass\tAttendence\n");
                String student_info;
                while(row_index != rows)
                {
                    student_info = "";
                    for(int i = 0; i < column; i++)
                    {
                        rowData[i] = table1.getValueAt(row_index,i);

                    }
                    for(int i= 0; i < 4; i++)
                    {
                        student_info = student_info + rowData[i] + "\t";


                    }
                    fout.write(student_info+"\n");
                    System.out.println();
                    row_index += 1;
                }
                fout.close();

            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
            frame.dispose();
        }
        else{   // if absent button is pressed then change the selected row to the absent

            int i = table1.getSelectedRow();    // taking the selected row
            System.out.println("selected row is " + i);

            for(int k = 0; k <= absent_mark_index; k++)
            {
                if(absent_mark[k] == i)     // if already changed this cell
                {
                    System.out.println("Marking present agAIN");
                    table1.setValueAt("-", i, 3);
                    absent_mark[k] = -1; // because now it is present
                    break;
                }
                else{
                    System.out.println("Marking it absent");
                    table1.setValueAt("A", i, 3);   // this line simply change the value of absent in a row
                    break;
                }
            }

            absent_mark[absent_mark_index] = i;
            absent_mark_index += 1;
        }

    }
}
