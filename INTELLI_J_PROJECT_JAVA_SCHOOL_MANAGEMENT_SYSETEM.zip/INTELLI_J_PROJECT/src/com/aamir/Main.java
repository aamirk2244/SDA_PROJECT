package com.aamir;

import Base_login_page.Base_Login;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        if(!Database_Connection.is_connection_made("jdbc:mysql://localhost:3306"))
        {
            return;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                startPageGUI();

            }
        });
    }
    private static void startPageGUI()
    {
        Base_Login ui = new Base_Login();
        JPanel get_base_page = ui.create_Base_page();
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(get_base_page);
        frame.pack();
        frame.setSize(800, 500);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        ui.start_base_page();

    }

}
