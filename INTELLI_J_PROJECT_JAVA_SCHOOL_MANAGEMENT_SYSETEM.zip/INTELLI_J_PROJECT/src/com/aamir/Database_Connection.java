package com.aamir;

import javafx.application.Application;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class Database_Connection  {

    public static boolean is_connection_made(String url)
    {
    //    String url = "jdbc:mysql://localhost:3306/Students";    // url pattern for database created
        String name = "root";   // user name of the database
        String pass = "";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");// to load the mysql driver
            Connection con = DriverManager.getConnection(url, name, pass);
            con.setAutoCommit(false);
            con.commit();

        }catch (Exception e){
            System.out.println("Network error");
            JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(null), "Server is not running!",
                    "Network Error", JOptionPane.ERROR_MESSAGE);
        return false;

        }
        return true;
    }
}
