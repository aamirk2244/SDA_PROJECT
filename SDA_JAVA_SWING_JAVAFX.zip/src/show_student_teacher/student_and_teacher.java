package show_student_teacher;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class student_and_teacher implements ItemListener {
    private JLabel head_text;
    private JTable table1;
    private JComboBox comboBox1;
    private JLabel class_label;
    private JPanel panel;
    private JLabel TotalStudent_label;
    private JFrame frame;
    public String[] s = new String[13];
    public void set_student_classes()
    {

       for(int i = 0; i < 13; i++)
       {
           if(i == 0)
           {
               s[i] = "All Students";
           }
           else
           {

               s[i] = Integer.toString(i);
           }
       };
    }
    public void create_table(String id , String Name, String class_or_subject)
    {
        String[] column = {id ,Name, class_or_subject};
        Object[][] data = null;
        table1.setModel(new DefaultTableModel(data, column));
       table1.setShowGrid(true);
    }

    public void set_frame(String heading, boolean show_student)
    {
        frame = new JFrame();
        panel.setLayout(new FlowLayout());
        head_text.setText(heading);
        frame.setVisible(true);
     //   frame.setLocationRelativeTo(null);
        frame.setSize(800, 500);
        frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        System.out.println("************ THIS IS PROBLEM");
        frame.setContentPane(panel);
        if(show_student)
        {
            class_label.setText("Class");
            for(int i = 0 ; i < 13; i++)
            {
                comboBox1.addItem(s[i]);
                if(i != 0)
                {
                    comboBox1.getItemAt(i);

                }

            }
         comboBox1.addItemListener(this);

        }
        else
        {
            class_label.setText("");
        }

    }


    public void main_of_student_and_teacher(boolean show_student, boolean show_teacher, JFrame temp_frame)
    {
        temp_frame.dispose();
        set_student_classes();
        if(show_student)
        {
            set_frame("Students List", true);
            show_student_of_class(0, show_student);
        }
        else if(show_teacher)
        {
            // 22 is dummy value in this case
            show_student_of_class(22, false);
            set_frame("Teachers List", false);
        }


    }
    private void show_student_of_class(int number, boolean is_show_student)
    {
       //  select * from student_list where student_class = "12";
        String position = Integer.toString(number);
        String query;
        if(is_show_student)
        {
            if(number == 0)
            {
                query = "select * from student_list";
            }
            else
            {
                query = "select * from student_list where student_class = " +  position;
            }
        }
        else
        {
            query = "select * from teacher_list";
        }

        Connection con;
        try{

            Class.forName("com.mysql.cj.jdbc.Driver");
            if(is_show_student)
            {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Students","root","");

            }
            else {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Teachers","root","");
            }
            PreparedStatement ps = con.prepareStatement(query);

            ResultSet rs = ps.executeQuery();
            int ID;
            String NAME;
            String CLASS_OR_subject;
            if(is_show_student)
            {
                create_table("Student Id", "Name ","Class");

            }
            else{
                create_table("Teacher Id", "Name ","Subject");

            }
            DefaultTableModel model = (DefaultTableModel) table1.getModel();
            int Total_students_or_teachers = 0;
            if(is_show_student)
            {
                while(rs.next())
                {

                    ID = rs.getInt("student_id");
                    NAME = rs.getString("student_name");
                    CLASS_OR_subject = rs.getString("student_class");
                    model.addRow(new Object[]{ID, NAME, CLASS_OR_subject});
                    Total_students_or_teachers += 1;
                }
                TotalStudent_label.setText("Total Students are " + Total_students_or_teachers);

            }
            else
            {
                while(rs.next())
                {

                    ID = rs.getInt("id");
                    NAME = rs.getString("Name");
                    CLASS_OR_subject = rs.getString("Subject");
                    model.addRow(new Object[]{ID, NAME, CLASS_OR_subject});
                    Total_students_or_teachers += 1;
                }
                comboBox1.setVisible(false);

                TotalStudent_label.setText("Total Teachers are " + Total_students_or_teachers);

            }

            table1.setRowHeight(22);
            TableColumnModel columnModel = table1.getColumnModel();
            columnModel.getColumn(1).setPreferredWidth(120);
            columnModel.getColumn(0).setPreferredWidth(10);
            columnModel.getColumn(2).setPreferredWidth(3);

        }
        catch(Exception e)
        {
            System.out.println("Error in connection"+e);
            JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(null), "Server is not running!",
                    "Network Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        System.out.println("ITEM LISTENER PRESSED");
        for(int i = 0 ; i < 13; i++)
        {
            if(e.getItem() == s[i])
            {
                show_student_of_class(i, true);
            }
        }

    }
}
