package Registration.Remove_Teacher;

import com.aamir.Database_Connection;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.*;

public class Remove_teacher extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception  // this is the builtin function of FXML
    {

        //stage is a window
        Parent root = FXMLLoader.load(getClass().getResource("remove_teacher_ui.fxml"));
        primaryStage.setTitle("Remove Teacher");

        primaryStage.setScene(new Scene(root));

        System.out.println(root.getStyle());

        primaryStage.show();

    }


    public static void base_main(JFrame tmp_frame)
    {
        tmp_frame.dispose();
        System.out.println("I am called brother");
        if(!Database_Connection.is_connection_made("jdbc:mysql://localhost:3306/Teachers"))
        {
            return;
        }
        launch();   // this will call to the start function by default

    }
}
