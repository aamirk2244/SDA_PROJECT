package Teacher;

//import Registration.Registration_Gui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Teacher_Gui implements ActionListener {
    private JButton button1;
    private JButton button2;
    private JPanel panel;
    private JLabel label;
    public void setActionCommand()
    {
        button1.setActionCommand("1");
        button2.setActionCommand("2");

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand() == "1")     // button register student has been clicked
        {
            System.out.println("ist button is clicked");
            return;
        }
        if(e.getActionCommand() == "2")
        {
            return;
        }

    }
    public static void main()
    {
        Teacher_Gui LOGIN = new Teacher_Gui();
        JFrame frame = new JFrame();
        frame.setSize(800, 300);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(LOGIN.panel);    // to add the panel to the frame
        frame.setVisible(true);
        LOGIN.button1.addActionListener(LOGIN);
        LOGIN.button2.addActionListener(LOGIN);
        LOGIN.setActionCommand();
    }
}
